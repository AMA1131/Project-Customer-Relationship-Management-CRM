package factory;

import java.util.concurrent.atomic.AtomicInteger;
import model.Entity;
import model.User;
import utils.InputValidator;

public class UserFactory  extends AbstractEntityFactory{
    private static final AtomicInteger idCounter = new AtomicInteger(1);

    @Override
    public Entity createEntity(Object... args){
        if (args.length < 4) {
            throw new IllegalArgumentException("Insufficient parameters to create a user");
        }

        String firstName = (String) args[0];
        String lastName = (String) args[1];
        String email = (String) args[2];
        String role = ((String) args[3]).trim().replaceAll("\\s+", "").toLowerCase();

        if (!(InputValidator.isValidName(firstName))) {
            throw new IllegalArgumentException ("Invalid firstname format");
        }
        if (!(InputValidator.isValidName(lastName))) {
            throw new IllegalArgumentException ("Invalid lastname format");
        }
        if (!(InputValidator.isValidEmail(email))) {
            throw new IllegalArgumentException ("Invalid email format");
        }
        if (role.isEmpty() || (!role.equals("admin") && !role.equals("user"))) {
            throw new IllegalArgumentException ("Invalid role: use admin or user");
        }

        return new User(idCounter.getAndIncrement(), firstName, lastName, email, role);

    }
}
