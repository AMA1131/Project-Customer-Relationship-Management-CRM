package factory;

import java.util.concurrent.atomic.AtomicInteger;

import model.Entity;
import model.composite_interaction.InteractionHistory;
import utils.Logger;

public class InteractionHistoryFactory extends AbstractEntityFactory{
    private static final AtomicInteger idCounter = new AtomicInteger(1);

    @Override
    public Entity createEntity(Object... args){
        if (args.length < 2) {
            throw new IllegalArgumentException("Insufficient parameters to create a Client");
        }
        String title = ((String) args[0]).trim().replaceAll("\\s+", " ").toLowerCase();
        int clientId = (int) args[1];

        if (title.isEmpty()) {
            throw new IllegalArgumentException ("Invalid name format");
        }
        if (clientId < 1) {
            throw new IllegalArgumentException("Client ID must be positive integers");
        }
        Logger.log("Created Interaction history " + title);
        return new InteractionHistory(idCounter.getAndIncrement(), title, clientId);
    }
}
