package factory;

import java.util.concurrent.atomic.AtomicInteger;

import model.Entity;
import model.Client;
import utils.InputValidator;

public class ClientFactory extends AbstractEntityFactory{
    
    private static final AtomicInteger idCounter = new AtomicInteger(1);

    @Override
    public Entity createEntity(Object... args){
        if (args.length < 5) {
            throw new IllegalArgumentException("Insufficient parameters to create a Client");
        }

        String firstName = (String) args[0];
        String lastName = (String) args[1];
        String email = (String) args[2];
        String phoneNumber = (String) args[3];
        String company = ((String) args[4]).trim().replaceAll("\\s+", " ");

        if (!(InputValidator.isValidName(firstName))) {
            throw new IllegalArgumentException ("Invalid firstname format");
        }
        if (!(InputValidator.isValidName(lastName))) {
            throw new IllegalArgumentException ("Invalid lastname format");
        }
        if (!(InputValidator.isValidEmail(email))) {
            throw new IllegalArgumentException ("Invalid email format");
        }
        if (!(InputValidator.isValidNumber(phoneNumber))) {
            throw new IllegalArgumentException ("Invalid phone number format");
        }

        return new Client(idCounter.getAndIncrement(), firstName, lastName, email, phoneNumber, ((company != null && !company.isEmpty()) ? company : "None"));

    }
}
