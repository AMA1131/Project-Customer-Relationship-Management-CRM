package test;

public class InteractionHistoryFileHandlerTest {
    
}
