package model;

import java.util.ArrayList;

public class Company implements Entity{
    private int id;
    private String name;
    private ArrayList<Client> clients;

    public Company(int id, String name) {
        this.id = id;
        this.name = name;
        this.clients = new ArrayList<>();
    }

    @Override
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Client> getClients() {
        return clients;
    }

    @Override
    public String toString() {
        return "Company [id=" + id + ", name= '" + name + "', clients= '" + clients.size() + "']";
    }
}
