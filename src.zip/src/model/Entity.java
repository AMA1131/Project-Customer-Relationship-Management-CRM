package model;

public interface Entity {
    int getId();
}
