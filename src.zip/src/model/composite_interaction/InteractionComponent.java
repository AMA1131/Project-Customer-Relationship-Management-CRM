package model.composite_interaction;

public interface InteractionComponent {
    void display();
    int getClientId();
}
